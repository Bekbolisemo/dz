package com.example.dz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText EditText_Email , EditText_Password;
    private Button button;
    private TextView textView;

    String email = "admin@gmail.com";
    String password = "admin";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText_Email = findViewById(R.id.Email);
        EditText_Password = findViewById(R.id.Password);
        button = findViewById(R.id.btn_click);
        textView = findViewById(R.id.textView_2);

        button.setOnClickListener(v ->{
            if (EditText_Email.getText().toString().equals(email) && EditText_Password.getText().toString().equals(password)){
                EditText_Password.setVisibility(View.GONE);
                EditText_Email.setVisibility(View.GONE);
                button.setVisibility(View.GONE);
                textView.setVisibility(View.GONE);
                Toast.makeText(this, "Вы успешно зашли!", Toast.LENGTH_SHORT).show();
            }else if (EditText_Email.getText().toString().isEmpty() && EditText_Password.getText().toString().isEmpty()){
                Toast.makeText(this, "Поля пустые,введите данные!", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "Неправильные данные!", Toast.LENGTH_SHORT).show();
            }
        });

        EditText_Email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            @Override
            public void afterTextChanged(Editable editable) {
                if (EditText_Email.getText().toString().isEmpty() && EditText_Password.getText().toString().isEmpty()){
                    button.setBackground(ContextCompat.getDrawable(MainActivity.this,R.drawable.ser));
                }else {
                    button.setBackground(ContextCompat.getDrawable(MainActivity.this, R.drawable.ginger));

                }


            }
        });
        EditText_Password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }
            @Override
            public void afterTextChanged(Editable editable) {
                if (EditText_Email.getText().toString().isEmpty() && EditText_Password.getText().toString().isEmpty()){
                    button.setBackground(ContextCompat.getDrawable(MainActivity.this,R.drawable.ser));
                }else {
                    button.setBackground(ContextCompat.getDrawable(MainActivity.this, R.drawable.ginger));

                }


            }
        });

    }
}
